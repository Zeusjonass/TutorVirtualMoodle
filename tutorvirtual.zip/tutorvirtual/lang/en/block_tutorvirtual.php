<?php
$string['pluginname'] = 'Tutor virtual';
$string['tutorVirtual'] = 'Virtual tutor';
$string['tutorVirtual:addinstance'] = 'Add a new virtual tutor block';
$string['tutorVirtual:myaddinstance'] = 'Add a new virtual tutor block to your moodle page';
$string['mensajeriaProfe'] = 'Messaging with the teacher';
$string['notificacionesTarea'] = 'Homework notifications';
$string['material'] = 'Class material';
$string['dudasPlat'] = 'Frequent platform doubts';
$string['dudasTarea'] = 'Homework or topic frequent doubts';
$string['notifMensaje'] = 'Message notifications';
$string['botonActividades'] = 'Actividades';
$string['footerDescripcion'] = 'Curso ';
