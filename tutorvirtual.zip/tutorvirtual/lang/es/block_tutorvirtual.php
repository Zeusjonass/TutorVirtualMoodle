<?php
$string['pluginname'] = 'Tutor virtual';
$string['tutorVirtual'] = 'Tutor Virtual';
$string['tutorVirtual:addinstance'] = 'Agrega un nuevo bloque de tutor virtual';
$string['tutorVirtual:myaddinstance'] = 'Agrega un nuevo tutor virtual a tu pagina de Moodle';
$string['mensajeriaProfe'] = 'Mensajeria con el profesor';
$string['notificacionesTarea'] = 'Notificaciones de tareas';
$string['material'] = 'Material de la materia';
$string['dudasPlat'] = 'Dudas frecuentes sobre la plataforma';
$string['dudasTarea'] = 'Dudas frecuentes sobre la tarea o tema';
$string['notifMensaje'] = 'Notificaciones de mensajes';
